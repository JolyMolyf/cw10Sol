CREATE PROCEDURE Dept_Job 
@job Varchar(20) = 'MANAGER' ,
@Deptno Int = 10 AS 
BEGIN SELECT Ename, Job, Deptno 
FROM emp WHERE job = @job AND Deptno = @Deptno; END;
go

