CREATE procedure addUser
@numerGrupy varchar(30),
@idRokAkademicki varchar(30),
@imie varchar(30), 
@nazwisko varchar(30)
As
Begin
	
	--- check if student exists 
		Declare @idGrupy int
		Declare @idOsoba int  
	if exists (Select imie, nazwisko from Student inner join Osoba on Student.IdOsoba = Osoba.IdOsoba where Imie like @imie and Nazwisko like @nazwisko)
	Begin 
		print('student exists')
		-- check if group exists
		if exists (Select * from Grupa where Grupa.NrGrupy like @numerGrupy and idRokAkademicki like @idRokAkademicki)
		Begin 
			print('Grupa exists')
			Select @idGrupy = idGrupa from Grupa where NrGrupy  like @numerGrupy
			Select @idOsoba = Student.idOsoba from Student inner join Osoba on Osoba.IdOsoba = Student.IdOsoba where imie like @imie and nazwisko like @nazwisko
			Insert into StudentGrupa  values(@idOsoba, @idGrupy)
		End
		Else 
		Begin 
			print('new Group inserted')
			Insert into Grupa values(@numerGrupy, 1, @idRokAkademicki)
			Select @idGrupy = idGrupa from Grupa where NrGrupy  like @numerGrupy
			Select @idOsoba = Student.idOsoba from Student inner join Osoba on Osoba.IdOsoba = Student.IdOsoba where imie like @imie and nazwisko like @nazwisko
			Insert into StudentGrupa values(@idOsoba, @idGrupy)

		End
	End
	Else 
	Begin 
		Raiserror ('Błąd krytyczny: nie ma takiego studenta', 11, 20);
	End 

End

go

