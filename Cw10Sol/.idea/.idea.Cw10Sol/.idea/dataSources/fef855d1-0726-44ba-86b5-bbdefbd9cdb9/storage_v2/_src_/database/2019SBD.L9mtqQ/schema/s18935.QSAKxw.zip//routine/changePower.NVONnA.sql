Create procedure changePower 
@estimatedPower int
as 
Begin	
	Declare @IdEngine varchar(30)
	Declare @power varchar(30)
	Declare @version varchar(30)
	Declare @HybridUnit_id int

	Declare myCursor Cursor for  Select IdEngine, power, version, HybridUnit_id from Engine
	OPEN myCursor  
	FETCH NEXT FROM myCursor INTO @IdEngine, @power, @version, @HybridUnit_id  
		WHILE @@FETCH_STATUS = 0  
		BEGIN  
			 if @power < @estimatedPower 
			 Begin 
				Update Engine set power = @power + @power *0.1 where @IdEngine = IdEngine
			
			 End 
			 else
			 Begin 
			 	Update Engine set power = @power + @power *0.1 where @IdEngine = IdEngine
				
			 End
			  FETCH NEXT FROM myCursor INTO  @IdEngine, @power, @version, @HybridUnit_id 
		END 
	CLOSE myCursor  
	DEALLOCATE myCursor 
End ;
go

