CREATE procedure countByYear
@Datarekrutacki date, 
@Ile int = 0
AS 
Begin 
Select @Ile = COUNT(1) from Student where Year(DataRekrutacji) = Year(@Datarekrutacki);
return @Ile
End
go

