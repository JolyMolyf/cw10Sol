Create PROCEDURE emp_dat
@New_sal Money OUTPUT
AS
begin
SELECT ename, job, sal FROM EMP;
end

exec emp_data
go

