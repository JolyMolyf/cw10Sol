
CREATE procedure transferBetweenCities
@CityFrom Varchar(30) ,
@CityTo Varchar(30) 
As 
Begin 
Update Osoba Set Miasto = (Select idMiasto from Miasto where nazwa like @CityTo) where Miasto = (Select idMiasto from Miasto where nazwa = @CityFrom)
print(@@RowCount)
End
go

