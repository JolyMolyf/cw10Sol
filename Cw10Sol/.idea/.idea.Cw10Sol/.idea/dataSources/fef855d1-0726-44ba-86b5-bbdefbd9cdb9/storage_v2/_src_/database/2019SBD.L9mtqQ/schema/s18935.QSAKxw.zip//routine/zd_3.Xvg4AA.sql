CREATE Procedure zd_3 
@MiastoStart varchar, 
@MiastoEnd varchar,
@count int output
AS
begin 
Update Osoba set Osoba.Miasto = ( Select idMiasto from Miasto inner join Osoba on Osoba.Miasto =  Miasto.idMiasto where Miasto.nazwa Like @MiastoEnd ) 
where Osoba.Miasto = (Select Miasto from Osoba inner join Miasto on Osoba.Miasto = Miasto.idMiasto where Miasto.nazwa like @MiastoStart)
 
set @count = @@ROWCount
--print CAST(@count as varchar(20)) + 'cccc'
return @count;
end
go

